#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 12 16:01:53 2021

@author: luciennemicallef
"""
def hello():
    print("hello World")
    return
    
